import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { country, tab } = req.body;
  if (!country || !tab) return res.status(400).json({ error: "Missing params" });

  const prompts = {
    history: `Write a brief 3-sentence history of ${country}. Only the most fascinating highlights.`,
    food: `List 4 famous foods of ${country}. Return ONLY a raw JSON array, no markdown, no extra text: [{"emoji":"","name":"","desc":"one sentence"}]`,
    places: `List 4 famous tourist places in ${country}. Return ONLY a raw JSON array, no markdown, no extra text: [{"icon":"","name":"","desc":"one sentence"}]`,
  };

  try {
    const msg = await client.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 700,
      messages: [{ role: "user", content: prompts[tab] }],
    });
    const text = msg.content.map((c) => c.text || "").join("");
    res.status(200).json({ text });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
