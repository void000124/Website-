import { useEffect, useRef, useState, useCallback } from "react";
import Head from "next/head";

// ── Country data ──────────────────────────────────────────────────────────────
const NAMES = {
  "004":"Afghanistan","008":"Albania","012":"Algeria","024":"Angola","032":"Argentina",
  "036":"Australia","040":"Austria","050":"Bangladesh","056":"Belgium","064":"Bhutan",
  "068":"Bolivia","076":"Brazil","100":"Bulgaria","116":"Cambodia","120":"Cameroon",
  "124":"Canada","144":"Sri Lanka","152":"Chile","156":"China","170":"Colombia",
  "180":"DR Congo","188":"Costa Rica","191":"Croatia","192":"Cuba","203":"Czech Republic",
  "208":"Denmark","218":"Ecuador","818":"Egypt","231":"Ethiopia","246":"Finland",
  "250":"France","276":"Germany","288":"Ghana","300":"Greece","320":"Guatemala",
  "332":"Haiti","340":"Honduras","348":"Hungary","356":"India","360":"Indonesia",
  "364":"Iran","368":"Iraq","372":"Ireland","376":"Israel","380":"Italy","388":"Jamaica",
  "392":"Japan","400":"Jordan","398":"Kazakhstan","404":"Kenya","408":"North Korea",
  "410":"South Korea","414":"Kuwait","418":"Laos","422":"Lebanon","434":"Libya",
  "484":"Mexico","496":"Mongolia","504":"Morocco","508":"Mozambique","516":"Namibia",
  "524":"Nepal","528":"Netherlands","554":"New Zealand","566":"Nigeria","578":"Norway",
  "512":"Oman","586":"Pakistan","591":"Panama","600":"Paraguay","604":"Peru",
  "608":"Philippines","616":"Poland","620":"Portugal","634":"Qatar","642":"Romania",
  "643":"Russia","646":"Rwanda","682":"Saudi Arabia","686":"Senegal","706":"Somalia",
  "710":"South Africa","724":"Spain","729":"Sudan","752":"Sweden","756":"Switzerland",
  "760":"Syria","764":"Thailand","792":"Turkey","800":"Uganda","804":"Ukraine",
  "784":"United Arab Emirates","826":"United Kingdom","840":"United States",
  "858":"Uruguay","860":"Uzbekistan","862":"Venezuela","704":"Vietnam",
  "887":"Yemen","894":"Zambia","716":"Zimbabwe","222":"El Salvador","694":"Sierra Leone",
};

const FLAGS = {
  "Afghanistan":"🇦🇫","Albania":"🇦🇱","Algeria":"🇩🇿","Angola":"🇦🇴","Argentina":"🇦🇷",
  "Australia":"🇦🇺","Austria":"🇦🇹","Bangladesh":"🇧🇩","Belgium":"🇧🇪","Bolivia":"🇧🇴",
  "Brazil":"🇧🇷","Bulgaria":"🇧🇬","Cambodia":"🇰🇭","Cameroon":"🇨🇲","Canada":"🇨🇦",
  "Chile":"🇨🇱","China":"🇨🇳","Colombia":"🇨🇴","DR Congo":"🇨🇩","Costa Rica":"🇨🇷",
  "Croatia":"🇭🇷","Cuba":"🇨🇺","Czech Republic":"🇨🇿","Denmark":"🇩🇰","Ecuador":"🇪🇨",
  "Egypt":"🇪🇬","Ethiopia":"🇪🇹","Finland":"🇫🇮","France":"🇫🇷","Germany":"🇩🇪",
  "Ghana":"🇬🇭","Greece":"🇬🇷","Guatemala":"🇬🇹","Haiti":"🇭🇹","Honduras":"🇭🇳",
  "Hungary":"🇭🇺","India":"🇮🇳","Indonesia":"🇮🇩","Iran":"🇮🇷","Iraq":"🇮🇶",
  "Ireland":"🇮🇪","Israel":"🇮🇱","Italy":"🇮🇹","Jamaica":"🇯🇲","Japan":"🇯🇵",
  "Jordan":"🇯🇴","Kazakhstan":"🇰🇿","Kenya":"🇰🇪","North Korea":"🇰🇵","South Korea":"🇰🇷",
  "Kuwait":"🇰🇼","Laos":"🇱🇦","Lebanon":"🇱🇧","Libya":"🇱🇾","Mexico":"🇲🇽",
  "Mongolia":"🇲🇳","Morocco":"🇲🇦","Nepal":"🇳🇵","Netherlands":"🇳🇱","New Zealand":"🇳🇿",
  "Nigeria":"🇳🇬","Norway":"🇳🇴","Pakistan":"🇵🇰","Panama":"🇵🇦","Paraguay":"🇵🇾",
  "Peru":"🇵🇪","Philippines":"🇵🇭","Poland":"🇵🇱","Portugal":"🇵🇹","Qatar":"🇶🇦",
  "Romania":"🇷🇴","Russia":"🇷🇺","Rwanda":"🇷🇼","Saudi Arabia":"🇸🇦","Senegal":"🇸🇳",
  "Somalia":"🇸🇴","South Africa":"🇿🇦","Spain":"🇪🇸","Sudan":"🇸🇩","Sweden":"🇸🇪",
  "Switzerland":"🇨🇭","Syria":"🇸🇾","Thailand":"🇹🇭","Turkey":"🇹🇷","Uganda":"🇺🇬",
  "Ukraine":"🇺🇦","United Arab Emirates":"🇦🇪","United Kingdom":"🇬🇧","United States":"🇺🇸",
  "Uruguay":"🇺🇾","Venezuela":"🇻🇪","Vietnam":"🇻🇳","Yemen":"🇾🇪","Zambia":"🇿🇲",
  "Zimbabwe":"🇿🇼","Sri Lanka":"🇱🇰","Bhutan":"🇧🇹","El Salvador":"🇸🇻",
  "Mozambique":"🇲🇿","Namibia":"🇳🇦","Uzbekistan":"🇺🇿","Sierra Leone":"🇸🇱","Oman":"🇴🇲",
};

export default function Home() {
  const canvasRef = useRef(null);
  const threeRef = useRef({});

  const [tooltip, setTooltip] = useState({ visible: false, name: "", x: 0, y: 0 });
  const [panel, setPanel] = useState({ open: false, country: "", flag: "🌍" });
  const [tab, setTab] = useState("history");
  const [content, setContent] = useState(null);
  const [loading, setLoading] = useState(false);
  const [coords, setCoords] = useState("LAT 0.00° · LON 0.00°");
  const cacheRef = useRef({});

  // ── Load tab content ────────────────────────────────────────────
  const loadTab = useCallback(async (tabName, country) => {
    const key = `${country}_${tabName}`;
    if (cacheRef.current[key]) { setContent({ tab: tabName, text: cacheRef.current[key] }); return; }
    setLoading(true); setContent(null);
    try {
      const r = await fetch("/api/country", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ country, tab: tabName }),
      });
      const d = await r.json();
      cacheRef.current[key] = d.text;
      setContent({ tab: tabName, text: d.text });
    } catch { setContent({ tab: tabName, text: "Could not load data." }); }
    setLoading(false);
  }, []);

  // ── Init Three.js ───────────────────────────────────────────────
  useEffect(() => {
    let THREE, animId, isDrag = false, lastX = 0, lastY = 0, velX = 0, velY = 0;
    let zoom = 2.5, hoveredId = null, selectedId = null;
    let geoData = null;
    const canvas = canvasRef.current;

    async function init() {
      THREE = (await import("three")).default || await import("three");

      const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
      renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
      renderer.setSize(innerWidth, innerHeight);

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(45, innerWidth / innerHeight, 0.1, 1000);
      camera.position.z = zoom;

      // Stars
      const starGeo = new THREE.BufferGeometry();
      const sp = new Float32Array(9000);
      for (let i = 0; i < 9000; i++) sp[i] = (Math.random() - 0.5) * 600;
      starGeo.setAttribute("position", new THREE.BufferAttribute(sp, 3));
      scene.add(new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 0.5 })));

      // Lights
      scene.add(new THREE.AmbientLight(0x223355, 0.7));
      const sun = new THREE.DirectionalLight(0xfff8ee, 1.5);
      sun.position.set(5, 3, 5);
      scene.add(sun);

      // Textures
      const loader = new THREE.TextureLoader();
      const earthTex = loader.load("https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg");
      const bumpTex  = loader.load("https://unpkg.com/three-globe/example/img/earth-topology.png");
      const specTex  = loader.load("https://unpkg.com/three-globe/example/img/earth-water.png");
      const cloudTex = loader.load("https://unpkg.com/three-globe/example/img/earth-clouds.png");

      const earth = new THREE.Mesh(
        new THREE.SphereGeometry(1, 64, 64),
        new THREE.MeshPhongMaterial({ map: earthTex, bumpMap: bumpTex, bumpScale: 0.05, specularMap: specTex, specular: new THREE.Color(0x226688), shininess: 18 })
      );
      scene.add(earth);

      const clouds = new THREE.Mesh(
        new THREE.SphereGeometry(1.012, 64, 64),
        new THREE.MeshPhongMaterial({ map: cloudTex, transparent: true, opacity: 0.38, depthWrite: false })
      );
      scene.add(clouds);

      scene.add(new THREE.Mesh(
        new THREE.SphereGeometry(1.07, 64, 64),
        new THREE.MeshPhongMaterial({ color: 0x4488ff, transparent: true, opacity: 0.07, side: THREE.FrontSide, depthWrite: false })
      ));

      // Border overlay canvas
      const bCanvas = document.createElement("canvas");
      bCanvas.width = 2048; bCanvas.height = 1024;
      const bCtx = bCanvas.getContext("2d");
      const bTex = new THREE.CanvasTexture(bCanvas);
      const borderMesh = new THREE.Mesh(
        new THREE.SphereGeometry(1.003, 64, 64),
        new THREE.MeshBasicMaterial({ map: bTex, transparent: true, depthWrite: false })
      );
      scene.add(borderMesh);

      function drawBorders(hId, sId) {
        if (!geoData || !window._d3 || !window._topo3) return;
        bCtx.clearRect(0, 0, 2048, 1024);
        const proj = window._d3.geoEquirectangular().scale(2048 / (2 * Math.PI)).translate([1024, 512]);
        const path = window._d3.geoPath(proj, bCtx);
        geoData.forEach(f => {
          const id = f.id?.toString().padStart(3, "0");
          bCtx.beginPath(); path(f);
          if (id === sId) { bCtx.fillStyle = "rgba(255,100,40,0.45)"; bCtx.strokeStyle = "rgba(255,130,60,0.9)"; bCtx.lineWidth = 2; }
          else if (id === hId) { bCtx.fillStyle = "rgba(0,210,255,0.3)"; bCtx.strokeStyle = "rgba(0,220,255,0.9)"; bCtx.lineWidth = 1.5; }
          else { bCtx.fillStyle = "rgba(0,0,0,0)"; bCtx.strokeStyle = "rgba(255,255,255,0.15)"; bCtx.lineWidth = 0.5; }
          bCtx.fill(); bCtx.stroke();
        });
        bTex.needsUpdate = true;
      }

      threeRef.current = { drawBorders, scene, camera, renderer, earth, clouds, borderMesh, bTex };

      // Load D3 + topo
      await new Promise(res => {
        const s1 = document.createElement("script");
        s1.src = "https://cdnjs.cloudflare.com/ajax/libs/topojson/3.0.2/topojson.min.js";
        document.head.appendChild(s1);
        s1.onload = () => {
          const s2 = document.createElement("script");
          s2.src = "https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js";
          document.head.appendChild(s2);
          s2.onload = async () => {
            window._d3 = d3;
            const r = await fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json");
            window._topo3 = await r.json();
            geoData = topojson.feature(window._topo3, window._topo3.objects.countries).features;
            drawBorders(null, null);
            res();
          };
        };
      });

      // Raycaster
      const raycaster = new THREE.Raycaster();
      const mouse = new THREE.Vector2();

      function getCountryAtUV(uv) {
        if (!geoData || !window._d3) return null;
        const lon = uv.x * 360 - 180, lat = (1 - uv.y) * 180 - 90;
        for (const f of geoData) {
          if (window._d3.geoContains(f, [lon, lat])) return f;
        }
        return null;
      }

      function onMouseMove(e) {
        mouse.x = (e.clientX / innerWidth) * 2 - 1;
        mouse.y = -(e.clientY / innerHeight) * 2 + 1;
        if (isDrag) { setTooltip(t => ({ ...t, visible: false })); return; }
        raycaster.setFromCamera(mouse, camera);
        const hits = raycaster.intersectObject(earth);
        if (hits.length && hits[0].uv) {
          const uv = hits[0].uv;
          const lon = uv.x * 360 - 180, lat = (1 - uv.y) * 180 - 90;
          setCoords(`LAT ${lat.toFixed(2)}° · LON ${lon.toFixed(2)}°`);
          const f = getCountryAtUV(uv);
          const newId = f ? f.id?.toString().padStart(3, "0") : null;
          if (newId !== hoveredId) {
            hoveredId = newId;
            drawBorders(hoveredId, selectedId);
          }
          if (f && NAMES[newId]) {
            setTooltip({ visible: true, name: NAMES[newId], x: e.clientX, y: e.clientY });
            canvas.style.cursor = "pointer";
          } else {
            setTooltip(t => ({ ...t, visible: false }));
            canvas.style.cursor = "grab";
          }
        } else {
          setTooltip(t => ({ ...t, visible: false }));
          canvas.style.cursor = "grab";
          if (hoveredId) { hoveredId = null; drawBorders(null, selectedId); }
        }
      }

      let downX = 0, downY = 0;
      canvas.addEventListener("mousedown", e => { isDrag = true; lastX = downX = e.clientX; lastY = downY = e.clientY; velX = velY = 0; canvas.style.cursor = "grabbing"; });
      canvas.addEventListener("mousemove", e => {
        if (isDrag) { const dx = e.clientX - lastX, dy = e.clientY - lastY; velY = dx * 0.003; velX = dy * 0.003; earth.rotation.y += velY; earth.rotation.x += velX; clouds.rotation.y += velY; clouds.rotation.x += velX; borderMesh.rotation.copy(earth.rotation); lastX = e.clientX; lastY = e.clientY; return; }
        onMouseMove(e);
      });
      canvas.addEventListener("mouseup", e => {
        isDrag = false; canvas.style.cursor = "grab";
        const moved = Math.abs(e.clientX - downX) < 5 && Math.abs(e.clientY - downY) < 5;
        if (moved && hoveredId && NAMES[hoveredId]) {
          selectedId = hoveredId;
          drawBorders(hoveredId, selectedId);
          const name = NAMES[selectedId];
          setPanel({ open: true, country: name, flag: FLAGS[name] || "🌍" });
          setTab("history");
          cacheRef.current = {};
          loadTab("history", name);
        }
      });
      canvas.addEventListener("wheel", e => { e.preventDefault(); zoom = Math.max(1.2, Math.min(8, zoom * (e.deltaY > 0 ? 1.1 : 0.91))); camera.position.z = zoom; }, { passive: false });

      // Touch
      let lt, ld;
      canvas.addEventListener("touchstart", e => {
        if (e.touches.length === 1) { isDrag = true; lastX = e.touches[0].clientX; lastY = e.touches[0].clientY; lt = { x: lastX, y: lastY, t: Date.now() }; }
        if (e.touches.length === 2) { isDrag = false; ld = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); }
      });
      canvas.addEventListener("touchmove", e => {
        e.preventDefault();
        if (e.touches.length === 1 && isDrag) { const dx = e.touches[0].clientX - lastX, dy = e.touches[0].clientY - lastY; earth.rotation.y += dx * 0.003; earth.rotation.x += dy * 0.003; clouds.rotation.y += dx * 0.003; clouds.rotation.x += dy * 0.003; borderMesh.rotation.copy(earth.rotation); lastX = e.touches[0].clientX; lastY = e.touches[0].clientY; }
        if (e.touches.length === 2) { const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); zoom = Math.max(1.2, Math.min(8, zoom * (ld / d))); camera.position.z = zoom; ld = d; }
      }, { passive: false });
      canvas.addEventListener("touchend", e => { isDrag = false; });

      threeRef.current.zoomFn = (f) => { zoom = Math.max(1.2, Math.min(8, zoom * f)); camera.position.z = zoom; };
      threeRef.current.closePanel = () => { selectedId = null; drawBorders(hoveredId, null); };

      // Resize
      window.addEventListener("resize", () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });

      // Animate
      function animate() {
        animId = requestAnimationFrame(animate);
        if (!isDrag) { velX *= 0.97; velY *= 0.97; earth.rotation.x += velX; earth.rotation.y += velY; clouds.rotation.copy(earth.rotation); borderMesh.rotation.copy(earth.rotation); }
        clouds.rotation.y += 0.00008;
        renderer.render(scene, camera);
      }
      animate();
    }

    init();
    return () => { cancelAnimationFrame(animId); };
  }, [loadTab]);

  const handleTabChange = (newTab) => {
    setTab(newTab);
    loadTab(newTab, panel.country);
  };

  const handleClose = () => {
    setPanel(p => ({ ...p, open: false }));
    threeRef.current.closePanel?.();
  };

  // Render panel content
  function renderContent() {
    if (loading) return <div style={S.spin}><div style={S.spinner} /></div>;
    if (!content) return null;
    const { tab: t, text } = content;
    if (t === "history") return <div style={S.bodyText}>{text}</div>;
    try {
      const clean = text.replace(/```json|```/g, "").trim();
      const data = JSON.parse(clean);
      if (t === "food") return (
        <div style={S.foodGrid}>
          {data.map((f, i) => (
            <div key={i} style={S.foodCard}>
              <span style={{ fontSize: "1.6rem" }}>{f.emoji}</span>
              <div style={S.foodName}>{f.name}</div>
              <div style={S.foodDesc}>{f.desc}</div>
            </div>
          ))}
        </div>
      );
      if (t === "places") return (
        <div style={S.placeList}>
          {data.map((p, i) => (
            <div key={i} style={S.placeCard}>
              <span style={{ fontSize: "1.4rem", flexShrink: 0 }}>{p.icon}</span>
              <div>
                <div style={S.placeName}>{p.name}</div>
                <div style={S.placeDesc}>{p.desc}</div>
              </div>
            </div>
          ))}
        </div>
      );
    } catch { return <div style={S.bodyText}>{text}</div>; }
  }

  return (
    <>
      <Head><title>Earth Explorer</title></Head>

      <canvas ref={canvasRef} style={{ display: "block", width: "100vw", height: "100vh" }} />

      {/* Tooltip */}
      {tooltip.visible && (
        <div style={{ ...S.tip, left: tooltip.x, top: tooltip.y }}>
          {tooltip.name}
        </div>
      )}

      {/* Logo */}
      <div style={S.logo}>EARTH<span style={{ color: "#00cfff" }}>·</span>EXPLORER</div>
      <div style={S.hint}>DRAG · SCROLL · CLICK</div>

      {/* Side Panel */}
      <div style={{ ...S.panel, transform: panel.open ? "translateX(0)" : "translateX(100%)" }}>
        <div style={S.panelHead}>
          <button style={S.closeBtn} onClick={handleClose}>✕</button>
          <div style={{ fontSize: "2rem", marginBottom: 6 }}>{panel.flag}</div>
          <div style={S.panelName}>{panel.country}</div>
          <div style={S.panelSub}>Explore this country</div>
        </div>

        <div style={S.tabs}>
          {["history", "food", "places"].map(t => (
            <button key={t} style={{ ...S.tabBtn, ...(tab === t ? S.tabActive : {}) }} onClick={() => handleTabChange(t)}>
              {t === "history" ? "📜 History" : t === "food" ? "🍽 Food" : "🏛 Places"}
            </button>
          ))}
        </div>

        <div style={S.panelContent}>
          <div style={S.sectionLabel}>
            {tab === "history" ? "Historical Overview" : tab === "food" ? "Famous Cuisine" : "Must-Visit Places"}
          </div>
          {renderContent()}
        </div>
      </div>

      {/* Zoom */}
      <div style={S.zoomCtrl}>
        <button style={S.zBtn} onClick={() => threeRef.current.zoomFn?.(0.87)}>+</button>
        <button style={S.zBtn} onClick={() => threeRef.current.zoomFn?.(1.15)}>−</button>
      </div>

      {/* Coords */}
      <div style={S.coords}>{coords}</div>
    </>
  );
}

// ── Styles ──────────────────────────────────────────────────────────────────
const S = {
  tip: { position:"fixed", zIndex:20, pointerEvents:"none", transform:"translate(-50%,-160%)", background:"rgba(0,0,0,0.75)", border:"1px solid rgba(255,255,255,0.25)", backdropFilter:"blur(8px)", borderRadius:6, padding:"6px 14px", fontSize:13, color:"#fff", letterSpacing:"0.05em", whiteSpace:"nowrap" },
  logo: { position:"fixed", top:18, left:20, zIndex:10, fontSize:13, fontWeight:700, letterSpacing:"0.15em", color:"rgba(255,255,255,0.6)", textTransform:"uppercase", fontFamily:"sans-serif" },
  hint: { position:"fixed", top:18, right:20, zIndex:10, fontSize:10, color:"rgba(255,255,255,0.25)", letterSpacing:"0.08em", fontFamily:"sans-serif" },
  panel: { position:"fixed", right:0, top:0, bottom:0, width:340, zIndex:30, background:"rgba(5,10,20,0.9)", borderLeft:"1px solid rgba(255,255,255,0.09)", backdropFilter:"blur(24px)", transition:"transform 0.35s cubic-bezier(.23,1,.32,1)", display:"flex", flexDirection:"column", fontFamily:"sans-serif" },
  panelHead: { padding:"22px 20px 16px", borderBottom:"1px solid rgba(255,255,255,0.07)", position:"relative" },
  closeBtn: { position:"absolute", top:16, right:16, background:"none", border:"1px solid rgba(255,255,255,0.15)", color:"#888", width:28, height:28, borderRadius:"50%", cursor:"pointer", fontSize:12, display:"flex", alignItems:"center", justifyContent:"center" },
  panelName: { fontSize:"1.35rem", fontWeight:700, color:"#fff" },
  panelSub: { fontSize:11, color:"#445566", marginTop:2, letterSpacing:"0.07em", textTransform:"uppercase" },
  tabs: { display:"flex", borderBottom:"1px solid rgba(255,255,255,0.07)" },
  tabBtn: { flex:1, padding:"10px 4px", background:"none", border:"none", borderBottom:"2px solid transparent", color:"#445566", fontSize:11, letterSpacing:"0.07em", textTransform:"uppercase", cursor:"pointer", transition:"all .2s" },
  tabActive: { color:"#00cfff", borderBottomColor:"#00cfff" },
  panelContent: { flex:1, overflowY:"auto", padding:"20px" },
  sectionLabel: { fontSize:10, letterSpacing:"0.12em", textTransform:"uppercase", color:"#00cfff", marginBottom:12 },
  bodyText: { fontSize:13, lineHeight:1.75, color:"#99b0c8" },
  foodGrid: { display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 },
  foodCard: { background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:8, padding:10 },
  foodName: { fontSize:12, fontWeight:600, color:"#ddd", marginTop:4 },
  foodDesc: { fontSize:11, color:"#445566", marginTop:2 },
  placeList: { display:"flex", flexDirection:"column", gap:8 },
  placeCard: { background:"rgba(255,100,40,0.06)", border:"1px solid rgba(255,100,40,0.15)", borderRadius:8, padding:"10px 12px", display:"flex", gap:10, alignItems:"flex-start" },
  placeName: { fontSize:12, fontWeight:700, color:"#ff8055", marginBottom:2 },
  placeDesc: { fontSize:11, color:"#445566", lineHeight:1.5 },
  spin: { display:"flex", justifyContent:"center", paddingTop:60 },
  spinner: { width:30, height:30, border:"2px solid rgba(255,255,255,0.08)", borderTopColor:"#00cfff", borderRadius:"50%", animation:"spin 0.7s linear infinite" },
  zoomCtrl: { position:"fixed", bottom:30, left:20, zIndex:10, display:"flex", flexDirection:"column", gap:5 },
  zBtn: { width:36, height:36, background:"rgba(0,0,0,0.5)", border:"1px solid rgba(255,255,255,0.15)", color:"#fff", borderRadius:7, cursor:"pointer", fontSize:"1.1rem", display:"flex", alignItems:"center", justifyContent:"center", backdropFilter:"blur(8px)" },
  coords: { position:"fixed", bottom:30, left:"50%", transform:"translateX(-50%)", zIndex:10, fontSize:11, color:"rgba(255,255,255,0.3)", background:"rgba(0,0,0,0.4)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:20, padding:"5px 14px", letterSpacing:"0.07em", fontFamily:"monospace" },
};
