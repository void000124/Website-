# 🌍 Earth Explorer

Interactive 3D globe with country history, food & places — powered by Claude AI.

## Deploy to Vercel (step by step)

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "init"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/earth-explorer.git
git push -u origin main
```

### 2. Deploy on Vercel
1. Go to [vercel.com](https://vercel.com) → **Add New Project**
2. Import your GitHub repo
3. Under **Environment Variables**, add:
   - Key: `ANTHROPIC_API_KEY`
   - Value: your actual API key from [console.anthropic.com](https://console.anthropic.com)
4. Click **Deploy** ✅

### 3. Run locally
```bash
npm install
echo "ANTHROPIC_API_KEY=your_key_here" > .env.local
npm run dev
# Open http://localhost:3000
```

## Features
- 🌐 Realistic 3D Earth (NASA Blue Marble texture)
- ☁️ Live cloud layer with slow drift
- 🖱️ Drag to rotate, scroll to zoom, click a country
- 🤖 AI-powered history, food & places for every country
- 📱 Touch support for mobile
